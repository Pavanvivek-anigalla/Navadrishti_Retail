import json
import pandas as pd
import streamlit as st
from snowflake.snowpark.context import get_active_session

# --------------------------------------------------
# Page Configuration
# --------------------------------------------------

st.set_page_config(
    page_title="Navadrishti",
    page_icon="🚀",
    layout="wide"
)

session = get_active_session()

# --------------------------------------------------
# Agent Configuration
# --------------------------------------------------

AGENT_MAP = {
    "Product Matching": "NAVADRISHTI_DB.RETAIL_INTELLIGENCE.PRODUCT_MATCHING",
    "Pricing Intelligence": "NAVADRISHTI_DB.RETAIL_INTELLIGENCE.PRICING_INTELLIGENCE",
    "Market Intelligence": "NAVADRISHTI_DB.RETAIL_INTELLIGENCE.MARKET_INTELLIGENCE",
}

def call_agent(agent_fqn, user_message, history_key=None):
    """Call a Cortex Agent via DATA_AGENT_RUN SQL function."""
    # Build messages from chat history
    messages = []
    if history_key and history_key in st.session_state:
        for msg in st.session_state[history_key]:
            messages.append({
                "role": msg["role"],
                "content": [{"type": "text", "text": msg["content"]}]
            })
    messages.append({
        "role": "user",
        "content": [{"type": "text", "text": user_message}]
    })

    request_body = json.dumps({"messages": messages})

    result = session.sql(f"""
        SELECT TRY_PARSE_JSON(
            SNOWFLAKE.CORTEX.DATA_AGENT_RUN(
                '{agent_fqn}',
                $${request_body}$$
            )
        ) AS resp
    """).collect()[0]["RESP"]

    resp = json.loads(result)

    # Extract text from response content
    content = resp.get("content", [])
    text_parts = []
    for item in content:
        if isinstance(item, dict) and item.get("type") == "text":
            text_parts.append(item["text"])
    return "\n\n".join(text_parts) if text_parts else "No response received."

def render_agent_chat(section_name, agent_fqn, placeholder_text):
    """Render a chat interface for an agent within a section."""
    history_key = f"chat_{section_name}"
    if history_key not in st.session_state:
        st.session_state[history_key] = []

    st.markdown("---")
    st.subheader(f"💬 Ask the {section_name} Agent")

    for msg in st.session_state[history_key]:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    if prompt := st.chat_input(placeholder_text, key=f"input_{section_name}"):
        st.session_state[history_key].append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.chat_message("assistant"):
            with st.spinner("Agent is thinking..."):
                try:
                    response = call_agent(agent_fqn, prompt, history_key)
                except Exception as e:
                    response = f"Error calling agent: {e}"
                st.markdown(response)
        st.session_state[history_key].append({"role": "assistant", "content": response})

# --------------------------------------------------
# Sidebar
# --------------------------------------------------

st.sidebar.title("🚀 Navadrishti")
st.sidebar.caption("AI-Powered Retail Intelligence Platform")

page = st.sidebar.radio(
    "Navigation",
    [
        "Executive Dashboard",
        "Product Matching",
        "Pricing Intelligence",
        "Market Intelligence",
        "Retail Assistant"
    ],
    key="main_navigation"
)

# ==================================================
# EXECUTIVE DASHBOARD
# ==================================================

if page == "Executive Dashboard":

    st.title("🚀 Navadrishti")
    st.subheader("AI-Powered Retail Intelligence Platform")

    st.markdown("""
    ### Retail Intelligence Platform

    Navadrishti helps retailers:

    - Match products across retailers
    - Identify pricing opportunities
    - Analyze market trends
    - Generate business insights
    """)

    abt_count = session.sql("""
    SELECT COUNT(*) CNT
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.ABT_PRODUCTS
    """).collect()[0]["CNT"]

    buy_count = session.sql("""
    SELECT COUNT(*) CNT
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.BUY_PRODUCTS
    """).collect()[0]["CNT"]

    matched_count = session.sql("""
    SELECT COUNT(*) CNT
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.PRODUCT_MATCH_RESULTS
    """).collect()[0]["CNT"]

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("ABT Products", abt_count)

    with col2:
        st.metric("BUY Products", buy_count)

    with col3:
        st.metric("Matched Products", matched_count)

    st.info("""
    ### 🚀 Active Components

    ✅ Product Matching Agent

    ✅ Pricing Intelligence Agent

    ✅ Market Intelligence Agent

    ✅ Retail Intelligence Assistant

    ✅ Executive Dashboard
    """)

    col4, col5 = st.columns(2)

    with col4:
        st.metric("Match Precision", "91%")

    with col5:
        st.metric("Pricing Opportunities", "95")

    st.markdown("---")

    st.subheader("🏆 Top Brands by Matched Products")

    top_brands = session.sql("""
    SELECT
        MANUFACTURER,
        MATCHED_PRODUCTS
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.MARKET_INTELLIGENCE
    ORDER BY MATCHED_PRODUCTS DESC
    LIMIT 10
    """).to_pandas()

    top_brands = top_brands.set_index("MANUFACTURER")

    st.bar_chart(top_brands)

    st.markdown("---")

    st.subheader("💰 Top Pricing Opportunities")

    pricing_df = session.sql("""
    SELECT
        ABT_PRODUCT,
        ABT_PRICE,
        BUY_PRICE,
        PRICE_DIFFERENCE,
        RECOMMENDATION
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.PRICING_RECOMMENDATIONS
    ORDER BY ABS(PRICE_DIFFERENCE) DESC
    LIMIT 10
    """).to_pandas()

    st.dataframe(pricing_df, use_container_width=True)

# ==================================================
# PRODUCT MATCHING
# ==================================================

elif page == "Product Matching":

    st.title("🔍 Product Matching Explorer")

    col1, col2 = st.columns(2)

    with col1:
        st.metric(
            "Total Matches Found",
            552
        )

    with col2:
        st.metric(
            "Match Precision",
            "91%"
        )

    st.info("""
    Product Matching Strategy

    ✅ Model Number Matching

    ✅ Model Number Normalization

    ✅ Similarity Matching

    ✅ Retail Product Entity Resolution

    Current Precision: 91%
    """)

    search_text = st.text_input(
        "Search Product Name"
    )

    if search_text:

        query = f"""
        SELECT
            P.ABT_ID,
            A.NAME AS ABT_PRODUCT,
            P.BUY_ID,
            B.NAME AS BUY_PRODUCT,
            P.MATCH_TYPE
        FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.PRODUCT_MATCH_RESULTS P
        JOIN NAVADRISHTI_DB.RETAIL_INTELLIGENCE.ABT_PRODUCTS A
            ON P.ABT_ID = A.ID
        JOIN NAVADRISHTI_DB.RETAIL_INTELLIGENCE.BUY_PRODUCTS B
            ON P.BUY_ID = B.ID
        WHERE UPPER(A.NAME) LIKE UPPER('%{search_text}%')
        """

        results = session.sql(query).to_pandas()

        st.dataframe(
            results,
            use_container_width=True
        )

    render_agent_chat(
        "Product Matching",
        AGENT_MAP["Product Matching"],
        "Ask about product matches, match types, scores..."
    )

# ==================================================
# PRICING INTELLIGENCE
# ==================================================

elif page == "Pricing Intelligence":

    st.title("💰 Pricing Intelligence")

    col1, col2 = st.columns(2)

    with col1:
        st.metric(
            "Pricing Opportunities",
            95
        )

    with col2:
        st.metric(
            "Highest Price Gap",
            "$849"
        )

    st.info("""
    Pricing Intelligence Agent

    ✅ Competitor Pricing Analysis

    ✅ Price Gap Detection

    ✅ Pricing Recommendations

    ✅ Revenue Optimization Insights
    """)

    pricing_df = session.sql("""
    SELECT
        ABT_PRODUCT,
        ABT_PRICE,
        BUY_PRICE,
        PRICE_DIFFERENCE,
        RECOMMENDATION
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.PRICING_RECOMMENDATIONS
    ORDER BY ABS(PRICE_DIFFERENCE) DESC
    LIMIT 20
    """).to_pandas()

    st.dataframe(
        pricing_df,
        use_container_width=True
    )

    render_agent_chat(
        "Pricing Intelligence",
        AGENT_MAP["Pricing Intelligence"],
        "Ask about pricing gaps, competitor analysis, recommendations..."
    )

# ==================================================
# MARKET INTELLIGENCE
# ==================================================

elif page == "Market Intelligence":

    st.title("📊 Market Intelligence")

    col1, col2 = st.columns(2)

    with col1:
        st.metric(
            "Top Brand",
            "Sony"
        )

    with col2:
        st.metric(
            "Highest Variance Brand",
            "Denon"
        )

    st.info("""
    Market Intelligence Agent

    ✅ Brand Performance Analysis

    ✅ Market Opportunity Detection

    ✅ Competitive Insights

    ✅ Strategic Recommendations
    """)

    market_df = session.sql("""
    SELECT *
    FROM NAVADRISHTI_DB.RETAIL_INTELLIGENCE.MARKET_INTELLIGENCE
    ORDER BY MATCHED_PRODUCTS DESC
    """).to_pandas()

    st.dataframe(
        market_df,
        use_container_width=True
    )

    render_agent_chat(
        "Market Intelligence",
        AGENT_MAP["Market Intelligence"],
        "Ask about market trends, brand performance, competitive insights..."
    )

# ==================================================
# RETAIL ASSISTANT
# ==================================================

elif page == "Retail Assistant":

    # Custom CSS for a polished chat UI
    st.markdown("""
    <style>
    .assistant-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 16px;
        margin-bottom: 1.5rem;
        color: white;
        text-align: center;
    }
    .assistant-header h1 {
        color: white !important;
        font-size: 2rem;
        margin-bottom: 0.3rem;
    }
    .assistant-header p {
        color: rgba(255,255,255,0.85);
        font-size: 1rem;
        margin: 0;
    }
    .suggestion-chip {
        display: inline-block;
        background: #f0f2f6;
        border: 1px solid #e0e3e8;
        border-radius: 20px;
        padding: 0.5rem 1rem;
        margin: 0.3rem;
        font-size: 0.85rem;
        color: #333;
        cursor: pointer;
        transition: all 0.2s;
    }
    .suggestion-chip:hover {
        background: #667eea;
        color: white;
        border-color: #667eea;
    }
    .chat-stats {
        display: flex;
        justify-content: center;
        gap: 2rem;
        margin-top: 1rem;
    }
    .stat-item {
        text-align: center;
    }
    .stat-value {
        font-size: 1.3rem;
        font-weight: 700;
        color: white;
    }
    .stat-label {
        font-size: 0.75rem;
        color: rgba(255,255,255,0.7);
    }
    </style>
    """, unsafe_allow_html=True)

    # Header with gradient banner
    st.markdown("""
    <div class="assistant-header">
        <h1>🤖 Navadrishti AI Assistant</h1>
        <p>Powered by Snowflake Cortex &mdash; ask me anything</p>
        <div class="chat-stats">
            <div class="stat-item">
                <div class="stat-value">Claude</div>
                <div class="stat-label">AI Model</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">Any Topic</div>
                <div class="stat-label">Coverage</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">Multi-turn</div>
                <div class="stat-label">Conversation</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    SYSTEM_PROMPT = (
        "You are Navadrishti AI Assistant, a helpful and knowledgeable assistant "
        "embedded in a retail intelligence platform. You can answer any question — "
        "retail, technology, general knowledge, coding, math, or casual conversation. "
        "Be concise, friendly, and accurate. Use markdown formatting for readability."
    )

    if "ai_chat_history" not in st.session_state:
        st.session_state.ai_chat_history = []
    if "uploaded_files_context" not in st.session_state:
        st.session_state.uploaded_files_context = {}  # {filename: extracted_text}

    def parse_file(f):
        """Parse an uploaded file and return extracted text."""
        fname = f.name
        ext = fname.rsplit(".", 1)[-1].lower()

        if ext in ("csv", "xlsx", "xls"):
            df = pd.read_csv(f) if ext == "csv" else pd.read_excel(f)
            preview = df.head(30).to_markdown(index=False)
            return (
                f"**{ext.upper()} file: {fname}**\n"
                f"Rows: {len(df)}, Columns: {len(df.columns)}\n"
                f"Columns: {', '.join(df.columns.tolist())}\n\n"
                f"First 30 rows:\n```\n{preview}\n```"
            )
        elif ext == "json":
            raw = f.read().decode("utf-8", errors="replace")
            pretty = json.dumps(json.loads(raw), indent=2)
            return f"**JSON file: {fname}**\n```json\n{pretty[:8000]}\n```"
        elif ext in ("pdf", "pptx", "ppt", "docx", "doc"):
            import tempfile, os
            raw_bytes = f.read()
            with tempfile.NamedTemporaryFile(delete=False, suffix=f'.{ext}') as tmp:
                tmp.write(raw_bytes)
                tmp_path = tmp.name
            try:
                session.sql("CREATE STAGE IF NOT EXISTS NAVADRISHTI_DB.RETAIL_INTELLIGENCE.TEMP_UPLOADS ENCRYPTION = (TYPE='SNOWFLAKE_SSE')").collect()
                session.file.put(tmp_path, "@NAVADRISHTI_DB.RETAIL_INTELLIGENCE.TEMP_UPLOADS", auto_compress=False, overwrite=True)
                tmp_fname = os.path.basename(tmp_path)
                result = session.sql(f"""
                    SELECT AI_PARSE_DOCUMENT(
                        TO_FILE('@NAVADRISHTI_DB.RETAIL_INTELLIGENCE.TEMP_UPLOADS', '{tmp_fname}'),
                        {{'mode': 'OCR'}}
                    ):content::STRING AS content
                """).collect()[0]["CONTENT"]
                return f"**{ext.upper()} file: {fname}**\n\n{result[:10000]}"
            finally:
                os.unlink(tmp_path)
        else:
            raw = f.read().decode("utf-8", errors="replace")
            return f"**File: {fname}**\n```\n{raw[:8000]}\n```"

    # Show suggestion chips when chat is empty
    if not st.session_state.ai_chat_history:
        st.markdown("#### 💡 Try asking about...")
        suggestions = [
            "Explain product matching strategies in retail",
            "What are the latest trends in competitive pricing?",
            "Write a Python function to calculate price elasticity",
            "How does Jaro-Winkler similarity work?",
            "Give me tips for building a retail analytics dashboard",
            "What is a semantic view in Snowflake?",
        ]
        cols = st.columns(2)
        for i, suggestion in enumerate(suggestions):
            with cols[i % 2]:
                if st.button(f"💬  {suggestion}", key=f"suggest_{i}", use_container_width=True):
                    st.session_state.ai_chat_history.append({"role": "user", "content": suggestion})
                    st.rerun()

    # Clear chat button in sidebar
    if st.session_state.ai_chat_history:
        if st.button("🗑️ Clear conversation", key="clear_chat"):
            st.session_state.ai_chat_history = []
            st.rerun()

    # Chat messages
    for msg in st.session_state.ai_chat_history:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    # ---------- File upload + chat input ----------
    uploaded_files = st.file_uploader(
        "📎 Attach files",
        type=["csv", "txt", "json", "md", "sql", "py", "log", "xml", "html", "pdf", "xlsx", "xls", "pptx", "ppt", "docx", "doc", "png", "jpg", "jpeg"],
        key="file_uploader",
        accept_multiple_files=True,
    )

    # Show attached file badges
    if st.session_state.uploaded_files_context:
        file_names = list(st.session_state.uploaded_files_context.keys())
        badge_text = " · ".join(f"📄 {n}" for n in file_names)
        st.caption(f"{badge_text}  —  {len(file_names)} file(s) attached")
        if st.button("✕ Remove all files", key="remove_files"):
            st.session_state.uploaded_files_context = {}
            st.rerun()

    # Chat input (Streamlit pins this to the bottom)
    prompt = st.chat_input("Message Navadrishti...", key="input_ai_assistant")

    # Process newly uploaded files
    if uploaded_files:
        current_names = {f.name for f in uploaded_files}
        existing_names = set(st.session_state.uploaded_files_context.keys())
        new_files = [f for f in uploaded_files if f.name not in existing_names]

        if new_files:
            for f in new_files:
                try:
                    st.session_state.uploaded_files_context[f.name] = parse_file(f)
                except Exception as e:
                    st.error(f"Could not read {f.name}: {e}")

            names = ", ".join(f"**{f.name}**" for f in new_files)
            if len(new_files) == 1:
                msg = f"I've uploaded a file: {names}. Please analyze it and give me a summary of its contents."
            else:
                msg = f"I've uploaded {len(new_files)} files: {names}. Please analyze and compare them."

            st.session_state.ai_chat_history.append({"role": "user", "content": msg})
            st.rerun()

    # ---------- Generate response ----------
    needs_response = (
        st.session_state.ai_chat_history
        and st.session_state.ai_chat_history[-1]["role"] == "user"
    )

    if prompt:
        st.session_state.ai_chat_history.append({"role": "user", "content": prompt})
        needs_response = True

    if needs_response:
        if prompt:
            with st.chat_message("user"):
                st.markdown(prompt)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                recent = st.session_state.ai_chat_history[-10:]
                conversation = f"<system>{SYSTEM_PROMPT}</system>\n"

                if st.session_state.uploaded_files_context:
                    all_files_text = "\n\n---\n\n".join(
                        st.session_state.uploaded_files_context.values()
                    )
                    conversation += (
                        f"<system>The user has uploaded {len(st.session_state.uploaded_files_context)} file(s). "
                        f"Here are their contents:\n\n"
                        f"{all_files_text}\n\n"
                        f"Use these file contents to answer the user's questions. "
                        f"If multiple files are present, you can compare and contrast them.</system>\n"
                    )

                for msg in recent:
                    tag = "user" if msg["role"] == "user" else "assistant"
                    conversation += f"<{tag}>{msg['content']}</{tag}>\n"

                escaped = conversation.replace("'", "''")
                try:
                    result = session.sql(f"""
                        SELECT SNOWFLAKE.CORTEX.COMPLETE(
                            'claude-sonnet-4-5',
                            '{escaped}'
                        ) AS response
                    """).collect()[0]["RESPONSE"]
                    response = result.strip('" ')
                except Exception as e:
                    response = f"Error: {e}"

                st.markdown(response)
        st.session_state.ai_chat_history.append({"role": "assistant", "content": response})

